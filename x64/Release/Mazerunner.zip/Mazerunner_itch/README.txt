When you are done playing the game close it with the in game option or else it will keep running in the background
It's a probleme I can't manage to solve sorry

Have Fun!